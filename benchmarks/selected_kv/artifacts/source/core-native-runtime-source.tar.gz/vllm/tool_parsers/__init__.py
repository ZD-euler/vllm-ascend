# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project

from vllm.tool_parsers.abstract_tool_parser import (
    ToolParser,
    ToolParserManager,
)

__all__ = ["ToolParser", "ToolParserManager"]


"""
Register a lazy module mapping.

Example:
    ToolParserManager.register_lazy_module(
        name="kimi_k2",
        module_path="vllm.tool_parsers.kimi_k2_tool_parser",
        class_name="KimiK2ToolParser",
    )
"""


_TOOL_PARSERS_TO_REGISTER = {
    "dots": (
        "dots_tool_parser",
        "DotsToolParser",
    ),
    "deepseek_v3": (  # name
        "deepseekv3_tool_parser",  # filename
        "DeepSeekV3ToolParser",  # class_name
    ),
    "deepseek_v31": (
        "deepseekv31_tool_parser",
        "DeepSeekV31ToolParser",
    ),
    "deepseek_v32": (
        "deepseekv32_engine_tool_parser",
        "DeepSeekV32EngineToolParser",
    ),
    "deepseek_v4": (
        "deepseekv4_engine_tool_parser",
        "DeepSeekV4EngineToolParser",
    ),
    "deepseek_v41": (
        "deepseekv41_engine_tool_parser",
        "DeepSeekV41EngineToolParser",
    ),
    "cohere_command3": (
        "cohere_command_tool_parser",
        "CohereCommand3ToolParser",
    ),
    "cohere_command4": (
        "cohere_command_tool_parser",
        "CohereCommand4ToolParser",
    ),
    "ernie45": (
        "ernie45_tool_parser",
        "Ernie45ToolParser",
    ),
    "glm45": (
        "glm47_moe_tool_parser",
        "Glm47MoeModelToolParser",
    ),
    "glm47": (
        "glm47_moe_tool_parser",
        "Glm47MoeModelToolParser",
    ),
    "ling3": (
        "ling3_tool_parser",
        "Ling3ToolParser",
    ),
    "granite-20b-fc": (
        "granite_20b_fc_tool_parser",
        "Granite20bFCToolParser",
    ),
    "granite": (
        "granite_engine_tool_parser",
        "GraniteEngineToolParser",
    ),
    "granite4": (
        "granite4_tool_parser",
        "Granite4ToolParser",
    ),
    "hermes": (
        "hermes_tool_parser",
        "Hermes2ProToolParser",
    ),
    "poolside_v1": (
        "poolside_v1_tool_parser",
        "PoolsideV1ToolParser",
    ),
    "hunyuan_a13b": (
        "hunyuan_a13b_tool_parser",
        "HunyuanA13BToolParser",
    ),
    "hy_v3": (
        "hy_v3_tool_parser",
        "HYV3ToolParser",
    ),
    "hy_v4": (
        "hy_v4_tool_parser",
        "HYV4ToolParser",
    ),
    "internlm": (
        "internlm2_tool_parser",
        "Internlm2ToolParser",
    ),
    "jamba": (
        "jamba_tool_parser",
        "JambaToolParser",
    ),
    "lfm2": (
        "lfm2_tool_parser",
        "Lfm2ToolParser",
    ),
    "kimi_k2": (
        "kimi_k2_tool_parser",
        "KimiK2ToolParser",
    ),
    "kimi_k3": (
        "kimi_k3_tool_parser",
        "KimiK3ToolParser",
    ),
    "k2_horizon": (
        "k2_horizon_tool_parser",
        "K2HorizonToolParser",
    ),
    "llama3_json": (
        "llama_tool_parser",
        "Llama3JsonToolParser",
    ),
    "llama4_json": (
        "llama_tool_parser",
        "Llama3JsonToolParser",
    ),
    "llama4_pythonic": (
        "llama4_pythonic_tool_parser",
        "Llama4PythonicToolParser",
    ),
    "longcat": (
        "longcat_tool_parser",
        "LongcatFlashToolParser",
    ),
    "mimo": (
        "qwen3_engine_tool_parser",
        "Qwen3EngineToolParser",
    ),
    "minimax_m2": (
        "minimax_m2_tool_parser",
        "MinimaxM2ToolParser",
    ),
    "minimax_m3": (
        "minimax_m3_tool_parser",
        "MinimaxM3ToolParser",
    ),
    "minicpm5": (
        "minicpm5xml_tool_parser",
        "MiniCPM5XMLToolParser",
    ),
    "mistral": (
        "mistral_tool_parser",
        "MistralToolParser",
    ),
    "olmo3": (
        "olmo3_tool_parser",
        "Olmo3PythonicToolParser",
    ),
    "muse_glimmer": (
        "muse_glimmer_tool_parser",
        "MuseGlimmerToolParser",
    ),
    "openai": (
        "gptoss_tool_parser",
        "GptOssToolParser",
    ),
    "phi4_mini_json": (
        "phi4mini_tool_parser",
        "Phi4MiniJsonToolParser",
    ),
    "pythonic": (
        "pythonic_tool_parser",
        "PythonicToolParser",
    ),
    "qwen3_coder": (
        "qwen3_engine_tool_parser",
        "Qwen3EngineToolParser",
    ),
    "qwen3_xml": (
        "qwen3_engine_tool_parser",
        "Qwen3EngineToolParser",
    ),
    "seed_oss": (
        "seed_oss_engine_tool_parser",
        "SeedOssEngineToolParser",
    ),
    "step3": (
        "step3_tool_parser",
        "Step3ToolParser",
    ),
    "step3p5": (
        "step3p5_tool_parser",
        "Step3p5ToolParser",
    ),
    "inkling": (
        "inkling_tool_parser",
        "InklingEngineToolParser",
    ),
    "xlam": (
        "xlam_tool_parser",
        "xLAMToolParser",
    ),
    "gigachat3": (
        "gigachat3_tool_parser",
        "GigaChat3ToolParser",
    ),
    "functiongemma": (
        "functiongemma_tool_parser",
        "FunctionGemmaToolParser",
    ),
    "gemma4": (
        "gemma4_engine_tool_parser",
        "Gemma4EngineToolParser",
    ),
    "apertus": (
        "apertus_tool_parser",
        "ApertusToolParser",
    ),
}


def register_lazy_tool_parsers():
    for name, (file_name, class_name) in _TOOL_PARSERS_TO_REGISTER.items():
        module_path = f"vllm.tool_parsers.{file_name}"
        ToolParserManager.register_lazy_module(name, module_path, class_name)


register_lazy_tool_parsers()
