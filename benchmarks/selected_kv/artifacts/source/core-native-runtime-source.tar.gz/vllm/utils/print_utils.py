# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project


def print_embeddings(embeds: list[float], prefix: str = "Embeddings"):
    embeds_trimmed = (str(embeds[:4])[:-1] + ", ...]") if len(embeds) > 4 else embeds
    print(f"{prefix}: {embeds_trimmed} (size={len(embeds)})")
