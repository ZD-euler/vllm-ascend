// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright contributors to the vLLM project

mod convert;
mod types;
mod validate;

use std::collections::HashMap;
use std::convert::Infallible;
use std::result::Result;
use std::sync::Arc;

use asynk_strim_attr::{TryYielder, try_stream};
use axum::Json;
use axum::extract::State;
use axum::http::HeaderMap;
use axum::response::sse::Event;
use axum::response::{IntoResponse, Response};
use futures::{Stream, StreamExt as _, pin_mut};
use thiserror_ext::AsReport as _;
use tracing::{error, info, trace};
use tracing_futures::Instrument as _;
use vllm_engine_core_client::protocol::logprobs::{Logprobs, PositionLogprobs};
use vllm_engine_core_client::protocol::multimodal::MmFeatureSpec;
use vllm_llm::{
    CollectedGenerateOutput, FinishReason, GenerateOutput, GenerateOutputStreamExt as _, TokenUsage,
};

use self::convert::{ResponseOptions, prepare_generate_request};
use self::types::{
    GenerateLogprob, GenerateResponse, GenerateResponseChoice, GenerateResponseStreamChoice,
    GenerateStreamResponse, MultiModalPlaceholders, PerRequestMetrics, PlaceholderRangeInfo,
    SpeculativeDecodingMetrics, StreamingSpeculativeDecodingMetrics,
};
pub(crate) use self::types::{GenerateRequest, GenerateSamplingParams};
pub(crate) use self::validate::validate_request_compat;
use crate::config::ApiServerOptions;
use crate::error::{ApiError, bail_server_error, server_error, text_submit_error};
use crate::routes::openai::utils::logprobs::clamp_logprob;
use crate::routes::openai::utils::types::{ChatLogProbs, ChatLogProbsContent, TopLogProb, Usage};
use crate::routes::openai::utils::validated_json::ValidatedJson;
use crate::state::AppState;
use crate::utils::{resolve_request_context, sse_response};

/// Validate one token-in/token-out request and proxy it into the shared
/// `vllm-text` stack.
pub async fn generate(
    State(state): State<Arc<AppState>>,
    headers: HeaderMap,
    ValidatedJson(mut body): ValidatedJson<GenerateRequest>,
) -> Response {
    let request_context = resolve_request_context(&headers, body.request_id.as_deref());
    let lora_resolution = state.resolve_model_with_loras(body.model.as_deref()).await;

    let mm_features = if let Some(parts) = body.content_parts.take() {
        match state
            .chat
            .prepare_media(parts, &mut body.token_ids)
            .instrument(vllm_chat::mm_request_span(&request_context.request_id))
            .await
        {
            Ok(features) => features,
            Err(e) => {
                return ApiError::invalid_request(
                    format!("failed to resolve content_parts: {}", e.as_report()),
                    Some("content_parts"),
                )
                .into_response();
            }
        }
    } else {
        None
    };
    let mm_placeholders = body
        .return_token_ids
        .unwrap_or(false)
        .then(|| extract_mm_placeholders(mm_features.as_deref()))
        .flatten();

    let prepared =
        match prepare_generate_request(body, &lora_resolution, request_context, mm_features) {
            Ok(prepared) => prepared,
            Err(error) => return error.into_response(),
        };
    let request_span = tracing::info_span!(
        "generate",
        request_id = %prepared.request_id,
        engine_request_id = tracing::field::Empty,
    );

    let api_server_options = state.api_server_options;
    let stream = prepared.stream;
    let raw_stream = match state
        .chat
        .text()
        .generate_raw(prepared.text_request)
        .instrument(request_span.clone())
        .await
    {
        Ok(stream) => stream,
        Err(error) => {
            return text_submit_error("failed to submit raw generate request", error)
                .into_response();
        }
    };

    if stream {
        let chunk_stream = generate_chunk_stream(
            raw_stream,
            prepared.request_id,
            api_server_options,
            prepared.options,
            mm_placeholders,
        );
        let sse_stream = generate_sse_stream(chunk_stream).instrument(request_span);

        return sse_response(sse_stream, api_server_options.sse_keep_alive_interval);
    }

    let collected = match raw_stream.collect_output().instrument(request_span.clone()).await {
        Ok(collected) => collected,
        Err(error) => {
            return server_error!(
                "failed to collect raw generate response: {}",
                error.to_report_string()
            )
            .into_response();
        }
    };

    let response = match collect_generate(
        collected,
        prepared.request_id,
        api_server_options,
        prepared.options,
        mm_placeholders,
    ) {
        Ok(response) => response,
        Err(error) => return error.into_response(),
    };

    Json(response).into_response()
}

#[try_stream]
async fn generate_chunk_stream(
    stream: impl Stream<Item = vllm_llm::Result<GenerateOutput>>,
    request_id: String,
    ApiServerOptions {
        enable_log_requests,
        enable_prompt_tokens_details,
        ..
    }: ApiServerOptions,
    ResponseOptions {
        include_usage,
        include_continuous_usage,
        include_logprobs,
        // Ignored: raw generate streaming has no prompt-logprobs wire shape.
        include_prompt_logprobs: _,
        return_token_ids,
    }: ResponseOptions,
    mut mm_placeholders: Option<MultiModalPlaceholders>,
    mut y: TryYielder<GenerateStreamResponse, ApiError>,
) -> Result<(), ApiError> {
    pin_mut!(stream);
    let mut prompt_tokens = None;
    let mut prompt_token_ids = None;
    let mut usage = TokenUsage::default();
    let mut spec_decode_metrics = None;

    while let Some(next) = stream.next().await {
        match next {
            Ok(output) => {
                if let Some(metrics) = output.spec_decode_metrics {
                    spec_decode_metrics = Some(SpeculativeDecodingMetrics::from(metrics));
                }
                if prompt_tokens.is_none()
                    && let Some(info) = output.prompt_info.as_ref()
                {
                    prompt_tokens = Some(info.prompt_token_ids.len());
                    if return_token_ids {
                        prompt_token_ids = Some(info.prompt_token_ids.to_vec());
                    }
                }
                usage.prompt_token_count = prompt_tokens.unwrap_or_default();
                usage.cached_token_count = usage.cached_token_count.max(output.cached_token_count);

                let token_ids = output.token_ids;
                usage.output_token_count = usage.output_token_count.saturating_add(token_ids.len());
                let finish_reason = output.finish_reason;

                if matches!(finish_reason.as_ref(), Some(FinishReason::Error)) {
                    bail_server_error!("Internal server error");
                }

                if let Some(finish_reason) = finish_reason.as_ref()
                    && enable_log_requests
                {
                    info!(
                        stream = true,
                        prompt_tokens = usage.prompt_token_count,
                        output_tokens = usage.output_token_count,
                        finish_reason = finish_reason.as_str(),
                        "generate finished"
                    );
                }

                if token_ids.is_empty() && finish_reason.is_none() {
                    continue;
                }

                let logprobs = if include_logprobs && !token_ids.is_empty() {
                    let logprobs = output.logprobs.as_ref().ok_or_else(|| {
                        server_error!(
                            "raw generate stream requested logprobs but generation returned none"
                        )
                    })?;
                    Some(raw_logprobs_to_openai_chat(logprobs)?)
                } else {
                    None
                };

                let prompt_token_ids = prompt_token_ids.take();
                y.yield_ok(GenerateStreamResponse {
                    request_id: request_id.clone(),
                    choices: vec![GenerateResponseStreamChoice {
                        index: 0,
                        logprobs,
                        finish_reason: finish_reason.map(|reason| reason.as_str().to_string()),
                        token_ids,
                    }],
                    usage: include_continuous_usage
                        .then(|| Usage::from_token_usage(usage, enable_prompt_tokens_details)),
                    mm_placeholders: prompt_token_ids.as_ref().and_then(|_| mm_placeholders.take()),
                    prompt_token_ids,
                    metrics: None,
                })
                .await;
            }
            Err(error) => {
                error!(
                    error = %error.as_report(),
                    "raw generate stream failed"
                );
                bail_server_error!("{}", error.to_report_string());
            }
        }
    }

    if include_usage {
        y.yield_ok(GenerateStreamResponse {
            request_id,
            choices: Vec::new(),
            usage: Some(Usage::from_token_usage(usage, enable_prompt_tokens_details)),
            prompt_token_ids: None,
            mm_placeholders: None,
            metrics: spec_decode_metrics.map(|speculative_decoding| PerRequestMetrics {
                speculative_decoding: StreamingSpeculativeDecodingMetrics::from(
                    speculative_decoding,
                ),
            }),
        })
        .await;
    }

    Ok(())
}

fn collect_generate(
    collected: CollectedGenerateOutput,
    request_id: String,
    ApiServerOptions {
        enable_log_requests,
        ..
    }: ApiServerOptions,
    ResponseOptions {
        // Ignored: non-streaming raw generate responses do not include usage.
        include_usage: _,
        // Ignored: continuous usage is a streaming-only option.
        include_continuous_usage: _,
        include_logprobs,
        include_prompt_logprobs,
        return_token_ids,
    }: ResponseOptions,
    mm_placeholders: Option<MultiModalPlaceholders>,
) -> Result<GenerateResponse, ApiError> {
    let logprobs = if include_logprobs {
        let logprobs = collected.logprobs.as_ref().ok_or_else(|| {
            ApiError::server_error(
                "raw generate response requested logprobs but generation returned none".to_string(),
            )
        })?;
        Some(raw_logprobs_to_openai_chat(logprobs)?)
    } else {
        None
    };
    let prompt_logprobs = if include_prompt_logprobs {
        match collected.prompt_logprobs.as_ref() {
            Some(prompt_logprobs) => Some(raw_prompt_logprobs_to_maps(prompt_logprobs)),
            // A single-token prompt has no scored positions; same mapping
            // as /v1/completions.
            None if collected.prompt_token_ids.len() == 1 => Some(vec![None]),
            None => {
                return Err(ApiError::server_error(
                    "raw generate response requested prompt_logprobs but generation returned none"
                        .to_string(),
                ));
            }
        }
    } else {
        None
    };
    let finish_reason = collected.finish_reason.as_str().to_string();

    if enable_log_requests {
        info!(
            prompt_tokens = collected.prompt_token_ids.len(),
            output_tokens = collected.token_ids.len(),
            %finish_reason,
            "generate finished"
        );
    }

    Ok(GenerateResponse {
        request_id,
        choices: vec![GenerateResponseChoice {
            index: 0,
            logprobs,
            finish_reason: Some(finish_reason),
            token_ids: collected.token_ids,
        }],
        prompt_logprobs,
        prompt_token_ids: return_token_ids.then_some(collected.prompt_token_ids),
        mm_placeholders: return_token_ids.then_some(mm_placeholders).flatten(),
        kv_transfer_params: collected.kv_transfer_params,
        ec_transfer_params: collected.ec_transfer_params,
        metrics: collected.spec_decode_metrics.map(|metrics| PerRequestMetrics {
            speculative_decoding: SpeculativeDecodingMetrics::from(metrics),
        }),
    })
}

fn extract_mm_placeholders(features: Option<&[MmFeatureSpec]>) -> Option<MultiModalPlaceholders> {
    let features = features?;
    if features.is_empty() {
        return None;
    }

    let mut placeholders = MultiModalPlaceholders::new();
    for feature in features {
        placeholders.entry(feature.modality.as_str().to_string()).or_default().push(
            PlaceholderRangeInfo {
                offset: feature.mm_position.offset,
                length: feature.mm_position.length,
            },
        );
    }
    for ranges in placeholders.values_mut() {
        ranges.sort_by_key(|range| range.offset);
    }
    Some(placeholders)
}

fn raw_logprobs_to_openai_chat(logprobs: &Logprobs) -> Result<ChatLogProbs, ApiError> {
    let content = logprobs
        .positions
        .iter()
        .map(position_to_chat_logprobs_content)
        .collect::<Result<Vec<_>, _>>()?;

    Ok(ChatLogProbs {
        content: Some(content),
    })
}

fn raw_prompt_logprobs_to_maps(
    prompt_logprobs: &Logprobs,
) -> Vec<Option<HashMap<u32, GenerateLogprob>>> {
    std::iter::once(None)
        .chain(
            prompt_logprobs
                .positions
                .iter()
                .map(|position| Some(position_to_logprob_map(position))),
        )
        .collect()
}

fn position_to_chat_logprobs_content(
    position: &PositionLogprobs,
) -> Result<ChatLogProbsContent, ApiError> {
    let chosen = position.entries.first().ok_or_else(|| {
        ApiError::server_error(
            "raw generate logprobs position unexpectedly had no token candidates".to_string(),
        )
    })?;
    let token = format_token_id(chosen.token_id);

    Ok(ChatLogProbsContent {
        token: token.clone(),
        logprob: clamp_logprob(chosen.logprob),
        bytes: Some(token.as_bytes().to_vec()),
        top_logprobs: position
            .entries
            .iter()
            .map(|entry| {
                let token = format_token_id(entry.token_id);
                TopLogProb {
                    token: token.clone(),
                    logprob: clamp_logprob(entry.logprob),
                    bytes: Some(token.into_bytes()),
                }
            })
            .collect(),
    })
}

fn position_to_logprob_map(position: &PositionLogprobs) -> HashMap<u32, GenerateLogprob> {
    position
        .entries
        .iter()
        .map(|entry| {
            (
                entry.token_id,
                GenerateLogprob {
                    logprob: clamp_logprob(entry.logprob),
                    rank: Some(entry.rank),
                    decoded_token: Some(format_token_id(entry.token_id)),
                },
            )
        })
        .collect()
}

fn format_token_id(token_id: u32) -> String {
    format!("token_id:{token_id}")
}

/// Convert one raw-generate chunk stream into SSE events.
#[try_stream]
async fn generate_sse_stream(
    stream: impl Stream<Item = Result<GenerateStreamResponse, ApiError>>,
    mut y: TryYielder<Event, Infallible>,
) -> Result<(), Infallible> {
    pin_mut!(stream);

    while let Some(next) = stream.next().await {
        match next {
            Ok(chunk) => y.yield_ok(to_sse_event(&chunk)).await,
            Err(error) => {
                y.yield_ok(to_error_sse_event(&error)).await;
                break;
            }
        }
    }

    y.yield_ok(done_sse_event()).await;
    Ok(())
}

fn to_sse_event(chunk: &GenerateStreamResponse) -> Event {
    trace!(?chunk, "generate emitting chunk");
    Event::default()
        .json_data(chunk)
        .expect("generate chunk must serialize to JSON")
}

fn to_error_sse_event(error: &ApiError) -> Event {
    let response = error.to_error_response();
    trace!(?response, "generate emitting error");
    Event::default()
        .json_data(response)
        .expect("ErrorResponse must serialize to JSON")
}

fn done_sse_event() -> Event {
    trace!("generate emitting done");
    Event::default().data("[DONE]")
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;

    use futures::{TryStreamExt as _, stream};
    use vllm_engine_core_client::protocol::multimodal::{MmModality, PlaceholderRange};
    use vllm_engine_core_client::protocol::output::RequestSpecDecodeMetrics;
    use vllm_llm::GeneratePromptInfo;

    use super::*;

    #[tokio::test]
    async fn generate_chunk_stream_captures_late_prompt_info() {
        let stream = stream::iter(vec![
            Ok(GenerateOutput {
                request_id: String::new(),
                prompt_info: None,
                token_ids: Vec::new(),
                logprobs: None,
                finish_reason: None,
                cached_token_count: 0,
                kv_transfer_params: None,
                ec_transfer_params: None,
                sampling_mask: None,
                spec_decode_metrics: None,
            }),
            Ok(GenerateOutput {
                request_id: String::new(),
                prompt_info: Some(GeneratePromptInfo {
                    prompt_token_ids: Arc::from([11_u32, 22_u32]),
                    prompt_logprobs: None,
                }),
                token_ids: vec![33],
                logprobs: None,
                finish_reason: Some(FinishReason::stop_eos()),
                cached_token_count: 2,
                kv_transfer_params: None,
                ec_transfer_params: None,
                sampling_mask: None,
                spec_decode_metrics: None,
            }),
        ]);

        let mm_placeholders = MultiModalPlaceholders::from([(
            "image".to_string(),
            vec![PlaceholderRangeInfo {
                offset: 1,
                length: 4,
            }],
        )]);
        let chunks: Vec<_> = generate_chunk_stream(
            stream,
            "raw-stream".to_string(),
            ApiServerOptions {
                enable_prompt_tokens_details: true,
                ..Default::default()
            },
            ResponseOptions {
                include_usage: true,
                include_continuous_usage: true,
                return_token_ids: true,
                ..Default::default()
            },
            Some(mm_placeholders.clone()),
        )
        .try_collect()
        .await
        .expect("collect chunks");

        assert_eq!(chunks.len(), 2);
        assert_eq!(chunks[0].prompt_token_ids, Some(vec![11, 22]));
        assert_eq!(chunks[0].mm_placeholders, Some(mm_placeholders));
        assert!(chunks[1].prompt_token_ids.is_none());
        assert!(chunks[1].mm_placeholders.is_none());
        assert_eq!(
            chunks[0].usage.as_ref().expect("chunk usage").prompt_tokens,
            2
        );
        assert_eq!(
            chunks[0]
                .usage
                .as_ref()
                .expect("chunk usage")
                .prompt_tokens_details
                .as_ref()
                .map(|details| details.cached_tokens),
            Some(2)
        );
        assert_eq!(
            chunks[1].usage.as_ref().expect("final usage").prompt_tokens,
            2
        );
        assert_eq!(
            chunks[1]
                .usage
                .as_ref()
                .expect("final usage")
                .prompt_tokens_details
                .as_ref()
                .map(|details| details.cached_tokens),
            Some(2)
        );
    }

    fn stream_output(
        prompt_token_ids: Option<&[u32]>,
        token_ids: Vec<u32>,
        finish_reason: Option<FinishReason>,
    ) -> GenerateOutput {
        GenerateOutput {
            request_id: String::new(),
            prompt_info: prompt_token_ids.map(|ids| GeneratePromptInfo {
                prompt_token_ids: Arc::from(ids),
                prompt_logprobs: None,
            }),
            token_ids,
            logprobs: None,
            finish_reason,
            cached_token_count: 0,
            kv_transfer_params: None,
            ec_transfer_params: None,
            sampling_mask: None,
            spec_decode_metrics: None,
        }
    }

    async fn collect_chunks(
        outputs: Vec<GenerateOutput>,
        return_token_ids: bool,
        mm_placeholders: Option<MultiModalPlaceholders>,
    ) -> Vec<GenerateStreamResponse> {
        generate_chunk_stream(
            stream::iter(outputs.into_iter().map(Ok)),
            "raw-stream".to_string(),
            ApiServerOptions::default(),
            ResponseOptions {
                return_token_ids,
                ..Default::default()
            },
            mm_placeholders,
        )
        .try_collect()
        .await
        .expect("collect chunks")
    }

    #[tokio::test]
    async fn generate_chunk_stream_omits_prompt_metadata_by_default() {
        let chunks = collect_chunks(
            vec![
                stream_output(Some(&[11, 22]), vec![33], None),
                stream_output(Some(&[11, 22]), vec![44], Some(FinishReason::stop_eos())),
            ],
            false,
            Some(MultiModalPlaceholders::from([(
                "image".to_string(),
                vec![PlaceholderRangeInfo {
                    offset: 1,
                    length: 4,
                }],
            )])),
        )
        .await;

        assert_eq!(chunks.len(), 2);
        assert!(chunks.iter().all(|c| c.prompt_token_ids.is_none()));
        assert!(chunks.iter().all(|c| c.mm_placeholders.is_none()));
    }

    #[tokio::test]
    async fn generate_chunk_stream_sends_prompt_metadata_on_first_emitted_chunk() {
        // An empty first output is skipped and must not consume the metadata.
        let chunks = collect_chunks(
            vec![
                stream_output(Some(&[11, 22]), Vec::new(), None),
                stream_output(Some(&[11, 22]), vec![33], None),
                stream_output(Some(&[11, 22]), vec![44], Some(FinishReason::stop_eos())),
            ],
            true,
            None,
        )
        .await;

        assert_eq!(chunks.len(), 2);
        assert_eq!(chunks[0].prompt_token_ids, Some(vec![11, 22]));
        assert!(chunks[0].mm_placeholders.is_none());
        assert!(chunks[1].prompt_token_ids.is_none());
        assert!(chunks[1].mm_placeholders.is_none());
    }

    #[tokio::test]
    async fn generate_chunk_stream_returns_terminal_spec_decode_metrics() {
        let metrics = RequestSpecDecodeMetrics {
            num_spec_tokens: 3,
            histogram: vec![0, 1, 1, 0],
            num_draft_tokens: 6,
            ..Default::default()
        };
        let mut output = stream_output(None, Vec::new(), Some(FinishReason::stop_eos()));
        output.spec_decode_metrics = Some(metrics.clone());

        for include_usage in [false, true] {
            let chunks: Vec<_> = generate_chunk_stream(
                stream::iter(vec![Ok(output.clone())]),
                "raw-stream".to_string(),
                ApiServerOptions::default(),
                ResponseOptions {
                    include_usage,
                    ..Default::default()
                },
                None,
            )
            .try_collect()
            .await
            .expect("collect chunks");
            assert_eq!(chunks.len(), 1 + usize::from(include_usage));
            assert!(chunks[0].metrics.is_none());
            if include_usage {
                assert!(chunks[1].choices.is_empty());
                assert_eq!(
                    chunks[1].metrics,
                    Some(PerRequestMetrics {
                        speculative_decoding: StreamingSpeculativeDecodingMetrics::from(
                            SpeculativeDecodingMetrics::from(metrics.clone())
                        )
                    })
                );
                let json = serde_json::to_value(&chunks[1]).expect("serialize chunk");
                let stats = &json["metrics"]["speculative_decoding"];
                assert_eq!(stats.as_object().expect("metrics object").len(), 7);
                assert_eq!(stats["num_draft_tokens"], 6);
                assert_eq!(stats["num_accepted_draft_tokens"], 3);
                assert_eq!(stats["mean_acceptance_length"], 2.5);
                assert_eq!(
                    stats["acceptance_histogram"],
                    serde_json::json!([0, 1, 1, 0])
                );
                assert!(stats.get("per_step_accepted").is_none());
            }
        }
    }

    #[test]
    fn spec_decode_metrics_zero_steps_and_detailed() {
        let empty = SpeculativeDecodingMetrics::from(RequestSpecDecodeMetrics {
            num_spec_tokens: 2,
            histogram: vec![0, 0, 0],
            ..Default::default()
        });
        assert_eq!(empty.mean_acceptance_length, 1.0);
        assert_eq!(empty.draft_acceptance_rate, 0.0);
        assert_eq!(empty.per_step_accepted, None);

        let detailed = SpeculativeDecodingMetrics::from(RequestSpecDecodeMetrics {
            num_spec_tokens: 2,
            histogram: vec![0, 1, 1],
            num_draft_tokens: 4,
            per_step_accepted: vec![1, 2],
            per_step_drafted: vec![2, 2],
        });
        assert_eq!(detailed.per_step_accepted, Some(vec![1, 2]));
        assert_eq!(detailed.per_step_drafted, Some(vec![2, 2]));
    }

    #[test]
    fn collect_generate_omits_prompt_metadata_by_default() {
        let output = CollectedGenerateOutput {
            request_id: "raw-1".to_string(),
            prompt_logprobs: None,
            token_ids: vec![30],
            logprobs: None,
            finish_reason: FinishReason::stop_eos(),
            usage: TokenUsage {
                prompt_token_count: 2,
                output_token_count: 1,
                cached_token_count: 0,
            },
            kv_transfer_params: None,
            ec_transfer_params: None,
            prompt_token_ids: vec![10, 20],
            sampling_mask: None,
            spec_decode_metrics: None,
        };

        let response = collect_generate(
            output,
            "raw-1".to_string(),
            ApiServerOptions::default(),
            ResponseOptions::default(),
            Some(MultiModalPlaceholders::from([(
                "image".to_string(),
                vec![PlaceholderRangeInfo {
                    offset: 0,
                    length: 1,
                }],
            )])),
        )
        .expect("response");

        assert!(response.prompt_token_ids.is_none());
        assert!(response.mm_placeholders.is_none());
    }

    #[test]
    fn collect_generate_returns_spec_decode_metrics() {
        let metrics = RequestSpecDecodeMetrics {
            num_spec_tokens: 3,
            histogram: vec![0, 1, 1, 0],
            num_draft_tokens: 6,
            ..Default::default()
        };
        let output = CollectedGenerateOutput {
            request_id: "raw-metrics".to_string(),
            prompt_logprobs: None,
            token_ids: vec![30],
            logprobs: None,
            finish_reason: FinishReason::stop_eos(),
            usage: TokenUsage::default(),
            kv_transfer_params: None,
            ec_transfer_params: None,
            prompt_token_ids: vec![10],
            sampling_mask: None,
            spec_decode_metrics: Some(metrics.clone()),
        };

        let response = collect_generate(
            output,
            "raw-metrics".to_string(),
            ApiServerOptions::default(),
            ResponseOptions::default(),
            None,
        )
        .expect("response");

        assert_eq!(
            response.metrics,
            Some(PerRequestMetrics {
                speculative_decoding: SpeculativeDecodingMetrics::from(metrics)
            })
        );
        let json = serde_json::to_value(&response).expect("serialize response");
        let stats = &json["metrics"]["speculative_decoding"];
        assert_eq!(stats.as_object().expect("metrics object").len(), 9);
        assert!(stats["per_step_accepted"].is_null());
        assert!(stats["per_step_drafted"].is_null());
    }

    #[test]
    fn extract_mm_placeholders_returns_none_without_features() {
        assert!(extract_mm_placeholders(None).is_none());
        assert!(extract_mm_placeholders(Some(&[])).is_none());
    }

    #[test]
    fn extract_mm_placeholders_groups_ranges_in_prompt_order() {
        let feature = |modality: MmModality, offset: usize, length: usize| MmFeatureSpec {
            data: None,
            modality,
            identifier: format!("{}-{offset}", modality.as_str()),
            mm_position: PlaceholderRange {
                offset,
                length,
                is_embed: None,
            },
            mm_hash: None,
        };
        let features = vec![
            feature(MmModality::Image, 8, 2),
            feature(MmModality::Audio, 4, 3),
            feature(MmModality::Image, 1, 5),
        ];

        let placeholders = extract_mm_placeholders(Some(&features)).expect("metadata");

        assert_eq!(
            placeholders["image"],
            vec![
                PlaceholderRangeInfo {
                    offset: 1,
                    length: 5,
                },
                PlaceholderRangeInfo {
                    offset: 8,
                    length: 2,
                },
            ]
        );
        assert_eq!(
            placeholders["audio"],
            vec![PlaceholderRangeInfo {
                offset: 4,
                length: 3,
            }]
        );
    }

    #[test]
    fn collect_generate_returns_prompt_token_ids_when_requested() {
        let output = CollectedGenerateOutput {
            request_id: "raw-1".to_string(),
            prompt_logprobs: None,
            token_ids: vec![30],
            logprobs: None,
            finish_reason: FinishReason::stop_eos(),
            usage: TokenUsage {
                prompt_token_count: 2,
                output_token_count: 1,
                cached_token_count: 0,
            },
            kv_transfer_params: None,
            ec_transfer_params: None,
            prompt_token_ids: vec![10, 20],
            sampling_mask: None,
            spec_decode_metrics: None,
        };

        let response = collect_generate(
            output,
            "raw-1".to_string(),
            ApiServerOptions::default(),
            ResponseOptions {
                return_token_ids: true,
                ..Default::default()
            },
            None,
        )
        .expect("response");

        assert_eq!(response.prompt_token_ids, Some(vec![10, 20]));
    }

    #[test]
    fn collect_generate_maps_prompt_logprobs_for_single_token_prompt() {
        let output_without_payload = |prompt_token_ids: Vec<u32>| CollectedGenerateOutput {
            request_id: "raw-1".to_string(),
            prompt_logprobs: None,
            token_ids: vec![3],
            logprobs: None,
            finish_reason: FinishReason::stop_eos(),
            usage: vllm_llm::TokenUsage {
                prompt_token_count: prompt_token_ids.len(),
                output_token_count: 1,
                cached_token_count: 0,
            },
            kv_transfer_params: None,
            ec_transfer_params: None,
            sampling_mask: None,
            spec_decode_metrics: None,
            prompt_token_ids,
        };

        let response = collect_generate(
            output_without_payload(vec![9707]),
            "raw-1".to_string(),
            ApiServerOptions::default(),
            ResponseOptions {
                include_prompt_logprobs: true,
                ..Default::default()
            },
            None,
        )
        .expect("single-token prompt without payload maps to [None]");
        let prompt_logprobs = response.prompt_logprobs.expect("prompt logprobs present");
        assert_eq!(prompt_logprobs.len(), 1);
        assert!(prompt_logprobs[0].is_none());

        collect_generate(
            output_without_payload(vec![9707, 11]),
            "raw-2".to_string(),
            ApiServerOptions::default(),
            ResponseOptions {
                include_prompt_logprobs: true,
                ..Default::default()
            },
            None,
        )
        .expect_err("multi-token prompt without payload is an engine failure");
    }
}
