// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright contributors to the vLLM project

use thiserror_ext::AsReport as _;
use vllm_text::tokenizer::Tokenizer;
use vllm_text::{Prompt, SamplingParams, TextDecodeOptions, TextRequest};

use super::types::CompletionRequest;
use crate::error::{ApiError, text_submit_error};
use crate::lora::LoraModelResolution;
use crate::routes::openai::completions::validate;
use crate::routes::openai::utils::resolve_generation_prompt_truncation;
use crate::routes::openai::utils::structured_outputs::convert_from_response_format_value;
use crate::utils::{
    ResolvedRequestContext, convert_logit_bias, merge_ec_transfer_params, merge_kv_transfer_params,
    resolve_session_id,
};

/// Lowered completion request plus the public response metadata carried by
/// every SSE chunk.
#[derive(Debug, Clone, PartialEq)]
pub(super) struct PreparedRequest {
    /// Stable OpenAI-style request ID, reused as the external text request ID.
    pub request_id: String,
    /// Public model ID echoed back to the client.
    pub response_model: String,
    /// Public response rendering options for route-layer helpers.
    pub options: ResponseOptions,
    /// Lowered text request for the shared `vllm-text` facade.
    pub text_request: TextRequest,
}

#[derive(Debug, Clone, Default, PartialEq)]
pub(super) struct ResponseOptions {
    /// Whether the caller asked for the final streamed usage chunk.
    pub include_usage: bool,
    /// Whether every streamed chunk should carry cumulative usage.
    pub include_continuous_usage: bool,
    /// Whether the caller requested prompt-only echo via `max_tokens=0`.
    pub prompt_only: bool,
    /// Prompt text that should be echoed back northbound when `echo=true`.
    pub echo: Option<String>,
    /// Whether the caller requested output logprobs on completion choices.
    pub requested_logprobs: Option<i32>,
    /// Whether the caller requested choice-level prompt logprobs.
    pub include_prompt_logprobs: bool,
    /// Whether to include token IDs alongside generated text.
    pub return_token_ids: bool,
    /// Whether to format logprob tokens as `token_id:{id}`.
    pub return_tokens_as_token_ids: bool,
}

/// Validate and lower one OpenAI completions request into the internal
/// text-generation format.
///
/// `lora_resolution.model_names` must be non-empty; the first entry is used as
/// the base `model` field in responses when no LoRA adapter is selected.
pub(super) fn prepare_completion_request(
    request: CompletionRequest,
    lora_resolution: &LoraModelResolution,
    ctx: ResolvedRequestContext,
    tokenizer: &dyn Tokenizer,
) -> Result<PreparedRequest, ApiError> {
    validate::validate_request_compat(&request, &lora_resolution.model_names)?;

    let prompt_truncation = resolve_generation_prompt_truncation(
        request.truncate_prompt_tokens,
        request.truncation_side,
    )
    .map_err(|error| text_submit_error("invalid prompt truncation", error))?;

    let request_id = format!("cmpl-{}", ctx.request_id);
    let response_model = lora_resolution
        .lora_request
        .as_ref()
        .map(|request| request.lora_name.clone())
        .unwrap_or_else(|| lora_resolution.model_names.first().cloned().unwrap_or_default());

    let logprobs = request.logprobs;
    let prompt_only = request.echo && request.max_tokens == Some(0);
    let prompt_logprobs =
        request.prompt_logprobs.or(if request.echo && (!request.stream || prompt_only) {
            logprobs
        } else {
            None
        });
    let include_usage = (request.stream_options.as_ref())
        .and_then(|options| options.include_usage)
        .unwrap_or(false);
    let include_continuous_usage = include_usage
        && request
            .stream_options
            .as_ref()
            .and_then(|options| options.continuous_usage_stats)
            .unwrap_or(false);
    let include_prompt_logprobs = prompt_logprobs.is_some();
    let max_tokens = if prompt_only {
        Some(1)
    } else {
        request.max_tokens
    };
    let echo = completion_echo_text(&request, tokenizer)?;

    let structured_outputs =
        convert_from_response_format_value(&request.response_format, &request.structured_outputs)?;
    let session_id = resolve_session_id(
        &ctx,
        request.session_id.as_deref(),
        request.vllm_xargs.as_ref(),
    );

    let text_request = TextRequest {
        request_id: request_id.clone(),
        prompt: request.prompt,
        mm_features: None,
        sampling_params: SamplingParams {
            temperature: request.temperature,
            watermarking: request.watermarking,
            top_p: request.top_p,
            top_k: request.top_k,
            seed: request.seed,
            max_tokens,
            min_tokens: request.min_tokens,
            thinking_token_budget: request.thinking_token_budget,
            logprobs,
            prompt_logprobs,
            min_p: request.min_p,
            frequency_penalty: request.frequency_penalty,
            presence_penalty: request.presence_penalty,
            repetition_penalty: request.repetition_penalty,
            repetition_detection: request.repetition_detection,
            stop_token_ids: request.stop_token_ids,
            ignore_eos: request.ignore_eos,
            logit_bias: convert_logit_bias(request.logit_bias)?,
            allowed_token_ids: request.allowed_token_ids,
            bad_words: None,
            logprob_token_ids: None,
            structured_outputs,
            skip_reading_prefix_cache: None,
            vllm_xargs: merge_kv_transfer_params(
                merge_ec_transfer_params(request.vllm_xargs, request.ec_transfer_params.as_ref()),
                request.kv_transfer_params.as_ref(),
            ),
        },
        decode_options: TextDecodeOptions {
            skip_special_tokens: request.skip_special_tokens,
            include_stop_str_in_output: request.include_stop_str_in_output,
            stop_strings: request.stop.map(|stop| stop.into_vec()),
            min_tokens: request.min_tokens.unwrap_or(0),
        },
        intermediate: request.stream,
        prompt_truncation,
        priority: ctx.priority.or(request.priority).unwrap_or(0),
        cache_salt: request.cache_salt,
        add_special_tokens: request.add_special_tokens,
        data_parallel_rank: ctx.data_parallel_rank,
        session_id,
        kv_hints: None,
        reasoning_parser_kwargs: Default::default(),
        reasoning_ended: None,
        lora_request: lora_resolution.lora_request.clone(),
        arrival_time: None,
    };

    Ok(PreparedRequest {
        request_id,
        response_model,
        options: ResponseOptions {
            include_usage,
            include_continuous_usage,
            prompt_only,
            echo,
            requested_logprobs: request.logprobs,
            include_prompt_logprobs,
            return_token_ids: request.return_token_ids.unwrap_or(false),
            return_tokens_as_token_ids: request.return_tokens_as_token_ids.unwrap_or(false),
        },
        text_request,
    })
}

fn completion_echo_text(
    request: &CompletionRequest,
    tokenizer: &dyn Tokenizer,
) -> Result<Option<String>, ApiError> {
    if !request.echo {
        return Ok(None);
    }

    match &request.prompt {
        Prompt::Text(prompt) => Ok(Some(prompt.clone())),
        Prompt::TokenIds(token_ids) if request.return_token_ids.unwrap_or(false) => {
            Ok(Some(String::new()))
        }
        Prompt::TokenIds(token_ids) => {
            tokenizer.decode(token_ids, false).map(Some).map_err(|error| {
                ApiError::invalid_request(
                    format!(
                        "Failed to decode token-ID prompt for echo: {}",
                        error.to_report_string()
                    ),
                    Some("prompt"),
                )
            })
        }
    }
}

#[cfg(test)]
mod tests {
    use axum::http::HeaderMap;
    use serde_json::json;
    use validator::Validate;
    use vllm_text::{Prompt, PromptTruncation, PromptTruncationLimit, TruncationSide};
    use vllm_tokenizer::test_utils::TestTokenizer;

    use super::prepare_completion_request;
    use crate::lora::LoraModelResolution;
    use crate::routes::openai::completions::types::CompletionRequest;
    use crate::routes::openai::utils::types::Normalizable;
    use crate::utils::{ResolvedRequestContext, resolve_request_context};

    fn request_context(headers: &HeaderMap, request_id: Option<&str>) -> ResolvedRequestContext {
        resolve_request_context(headers, request_id)
    }

    fn served(names: &[&str]) -> LoraModelResolution {
        LoraModelResolution {
            model_names: names.iter().map(|s| s.to_string()).collect(),
            lora_request: None,
        }
    }

    fn test_tokenizer() -> TestTokenizer {
        TestTokenizer::new()
    }

    fn base_request_json() -> serde_json::Value {
        json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "stream": true
        })
    }

    #[test]
    fn completion_http_request_deserializes_text_prompt() {
        let request: CompletionRequest =
            serde_json::from_value(base_request_json()).expect("parse request");

        assert_eq!(request.prompt, Prompt::Text("hello".to_string()));
        assert_eq!(request.model.as_deref(), Some("Qwen/Qwen1.5-0.5B-Chat"));
    }

    #[test]
    fn completion_http_request_defaults_missing_or_null_model() {
        for model in [None, Some(serde_json::Value::Null)] {
            let mut value = base_request_json();
            let object = value.as_object_mut().expect("request object");
            match model {
                Some(model) => {
                    object.insert("model".to_string(), model);
                }
                None => {
                    object.remove("model");
                }
            }

            let request: CompletionRequest =
                serde_json::from_value(value).expect("parse request without model");
            assert!(request.model.is_none());
        }

        let mut value = base_request_json();
        value
            .as_object_mut()
            .expect("request object")
            .insert("model".to_string(), json!(""));
        let request: CompletionRequest = serde_json::from_value(value).expect("parse empty model");
        assert_eq!(request.model.as_deref(), Some(""));
    }

    #[test]
    fn completion_http_request_deserializes_token_id_prompt() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": [11, 22, 33],
            "stream": true,
            "ignore_eos": true,
            "max_tokens": 7
        }))
        .expect("parse request");

        assert_eq!(request.prompt, Prompt::TokenIds(vec![11, 22, 33]));
        assert_eq!(request.max_tokens, Some(7));
        assert!(request.ignore_eos);
    }

    #[test]
    fn completion_http_request_rejects_empty_cache_salt() {
        let mut value = base_request_json();
        value
            .as_object_mut()
            .expect("request object")
            .insert("cache_salt".to_string(), json!(""));
        let request: CompletionRequest = serde_json::from_value(value).expect("parse cache_salt");

        assert!(request.validate().is_err());
    }

    #[test]
    fn prepare_completion_request_normalizes_top_k_sentinels() {
        for (top_k, expected) in [
            (serde_json::Value::Null, None),
            (json!(-1), Some(0)),
            (json!(0), Some(0)),
            (json!(20), Some(20)),
        ] {
            let mut value = base_request_json();
            value
                .as_object_mut()
                .expect("request object")
                .insert("top_k".to_string(), top_k);
            let request: CompletionRequest = serde_json::from_value(value).expect("parse top_k");
            let prepared = prepare_completion_request(
                request,
                &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
                ResolvedRequestContext::default(),
                &test_tokenizer(),
            )
            .expect("prepare top_k");

            assert_eq!(prepared.text_request.sampling_params.top_k, expected);
        }
    }

    #[test]
    fn prepare_completion_request_uses_left_when_side_is_omitted() {
        let mut value = base_request_json();
        value
            .as_object_mut()
            .expect("request object")
            .insert("truncate_prompt_tokens".to_string(), json!(-1));
        let request = serde_json::from_value(value).expect("parse truncation");
        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare truncation");

        assert_eq!(
            prepared.text_request.prompt_truncation,
            Some(PromptTruncation {
                limit: PromptTruncationLimit::InputBudget,
                side: TruncationSide::Left,
            })
        );
    }

    #[test]
    fn normalize_coerces_null_max_tokens_to_default() {
        // An absent `max_tokens` already gets the serde default.
        let absent: CompletionRequest =
            serde_json::from_value(base_request_json()).expect("parse request");
        assert_eq!(absent.max_tokens, Some(16));

        // An explicit `null` deserializes to `None`, bypassing the default;
        // `normalize` must coerce it back to match Python vLLM.
        let mut request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "stream": true,
            "max_tokens": null
        }))
        .expect("parse request");
        assert_eq!(request.max_tokens, None);

        request.normalize();
        assert_eq!(request.max_tokens, Some(16));
    }

    #[test]
    fn prepare_completion_request_maps_sampling_fields() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": [11, 22, 33],
            "stream": true,
            "stream_options": {"include_usage": true},
            "max_tokens": 7,
            "logprobs": 2,
            "top_p": 0.9,
            "top_k": 42,
            "min_p": 0.1,
            "frequency_penalty": 0.2,
            "presence_penalty": 0.3,
            "repetition_penalty": 1.1,
            "ignore_eos": true,
            "skip_special_tokens": false
        }))
        .expect("parse request");

        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare");

        assert!(prepared.options.include_usage);
        assert_eq!(
            prepared.text_request.prompt,
            Prompt::TokenIds(vec![11, 22, 33])
        );
        assert_eq!(prepared.text_request.sampling_params.max_tokens, Some(7));
        assert_eq!(prepared.text_request.sampling_params.logprobs, Some(2));
        assert_eq!(prepared.text_request.sampling_params.top_p, Some(0.9));
        assert_eq!(prepared.text_request.sampling_params.top_k, Some(42));
        assert_eq!(prepared.text_request.sampling_params.min_p, Some(0.1));
        assert_eq!(
            prepared.text_request.sampling_params.frequency_penalty,
            Some(0.2)
        );
        assert_eq!(
            prepared.text_request.sampling_params.presence_penalty,
            Some(0.3)
        );
        assert_eq!(
            prepared.text_request.sampling_params.repetition_penalty,
            Some(1.1)
        );
        assert!(prepared.text_request.sampling_params.ignore_eos);
        assert!(!prepared.text_request.decode_options.skip_special_tokens);
    }

    #[test]
    fn prepare_completion_request_passes_through_thinking_token_budget() {
        let prepare = |budget: serde_json::Value| {
            let request: CompletionRequest = serde_json::from_value(json!({
                "model": "Qwen/Qwen1.5-0.5B-Chat",
                "prompt": "hello",
                "thinking_token_budget": budget,
            }))
            .expect("parse request");
            prepare_completion_request(
                request,
                &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
                ResolvedRequestContext::default(),
                &test_tokenizer(),
            )
            .expect("prepare")
            .text_request
            .sampling_params
            .thinking_token_budget
        };

        // The convert layer forwards the raw value verbatim (including the `-1`
        // "unlimited" sentinel); normalization/validation happens during
        // lowering (see `vllm_text::lower`).
        assert_eq!(prepare(json!(64)), Some(64));
        assert_eq!(prepare(json!(-1)), Some(-1));
        assert_eq!(prepare(json!(null)), None);
    }

    #[test]
    fn prepare_completion_request_maps_stream_usage_and_token_format_options() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "stream": true,
            "stream_options": {
                "include_usage": true,
                "continuous_usage_stats": true
            },
            "return_tokens_as_token_ids": true
        }))
        .expect("parse request");

        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare");

        assert!(prepared.options.include_usage);
        assert!(prepared.options.include_continuous_usage);
        assert!(prepared.options.return_tokens_as_token_ids);
    }

    #[test]
    fn prepare_completion_request_gates_continuous_usage_on_include_usage() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "stream": true,
            "stream_options": {
                "continuous_usage_stats": true
            }
        }))
        .expect("parse request");

        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare");

        assert!(!prepared.options.include_usage);
        assert!(!prepared.options.include_continuous_usage);
    }

    #[test]
    fn prepare_completion_request_accepts_text_echo() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "stream": true,
            "echo": true,
            "max_tokens": 7
        }))
        .expect("parse request");

        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare");

        assert_eq!(prepared.options.echo, Some("hello".to_string()));
        assert_eq!(prepared.text_request.sampling_params.max_tokens, Some(7));
        assert!(!prepared.options.prompt_only);
    }

    #[test]
    fn prepare_completion_request_lowers_prompt_only_echo_as_one_internal_token() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "stream": false,
            "echo": true,
            "max_tokens": 0
        }))
        .expect("parse request");

        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare");

        assert!(prepared.options.prompt_only);
        assert_eq!(prepared.options.echo, Some("hello".to_string()));
        assert_eq!(prepared.text_request.sampling_params.max_tokens, Some(1));
    }

    #[test]
    fn prepare_completion_request_enables_prompt_logprobs_for_stream_prompt_only_echo() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "echo": true,
            "stream": true,
            "max_tokens": 0,
            "logprobs": 3
        }))
        .expect("parse request");

        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare");

        assert!(prepared.options.prompt_only);
        assert_eq!(prepared.text_request.sampling_params.logprobs, Some(3));
        assert_eq!(
            prepared.text_request.sampling_params.prompt_logprobs,
            Some(3)
        );
    }

    #[test]
    fn prepare_completion_request_enables_prompt_logprobs_for_non_stream_echo() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "echo": true,
            "stream": false,
            "logprobs": 3
        }))
        .expect("parse request");

        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare");

        assert_eq!(prepared.text_request.sampling_params.logprobs, Some(3));
        assert_eq!(
            prepared.text_request.sampling_params.prompt_logprobs,
            Some(3)
        );
    }

    #[test]
    fn prepare_completion_request_decodes_token_id_prompt_echo() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": [104, 101, 108, 108, 111],
            "stream": true,
            "echo": true
        }))
        .expect("parse request");

        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare");

        assert_eq!(prepared.options.echo, Some("hello".to_string()));
        assert_eq!(
            prepared.text_request.prompt,
            Prompt::TokenIds(vec![104, 101, 108, 108, 111])
        );
    }

    #[test]
    fn prepare_completion_request_accepts_logprobs_fields() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "stream": false,
            "logprobs": 1,
            "prompt_logprobs": 2
        }))
        .expect("parse request");

        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare");
        assert_eq!(prepared.text_request.sampling_params.logprobs, Some(1));
        assert_eq!(
            prepared.text_request.sampling_params.prompt_logprobs,
            Some(2)
        );
    }

    #[test]
    fn prepare_completion_request_accepts_full_vocab_logprobs() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "stream": false,
            "logprobs": -1
        }))
        .expect("parse request");

        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare full-vocabulary logprobs");

        assert_eq!(prepared.text_request.sampling_params.logprobs, Some(-1));
        assert_eq!(prepared.options.requested_logprobs, Some(-1));
    }

    #[test]
    fn prepare_completion_request_threads_data_parallel_rank() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "stream": false,
        }))
        .expect("parse request");

        let mut headers = HeaderMap::new();
        headers.insert("X-data-parallel-rank", "3".parse().unwrap());
        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            request_context(&headers, None),
            &test_tokenizer(),
        )
        .expect("prepare");
        assert_eq!(prepared.text_request.data_parallel_rank, Some(3));
    }

    #[test]
    fn prepare_completion_request_threads_body_session_id() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "stream": false,
            "session_id": "body-session",
            "vllm_xargs": {"session_id": "xargs-session"},
        }))
        .expect("parse request");

        let mut headers = HeaderMap::new();
        headers.insert("X-Session-ID", "header-session".parse().unwrap());
        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            request_context(&headers, None),
            &test_tokenizer(),
        )
        .expect("prepare");
        assert_eq!(
            prepared.text_request.session_id.as_deref(),
            Some("body-session")
        );
    }

    #[test]
    fn prepare_completion_request_header_priority_overrides_body() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "priority": 10,
        }))
        .expect("parse request");

        let mut headers = HeaderMap::new();
        headers.insert("X-Vllm-Priority", "-5".parse().unwrap());
        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            request_context(&headers, None),
            &test_tokenizer(),
        )
        .expect("prepare");
        assert_eq!(prepared.text_request.priority, -5);
    }

    #[test]
    fn prepare_completion_request_uses_vllm_xargs_session_id_fallback() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "stream": false,
            "vllm_xargs": {"session_id": "xargs-session"},
        }))
        .expect("parse request");

        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare");
        assert_eq!(
            prepared.text_request.session_id.as_deref(),
            Some("xargs-session")
        );
    }

    #[test]
    fn prepare_completion_request_ignores_empty_and_non_string_session_id_values() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "stream": false,
            "session_id": "",
            "vllm_xargs": {"session_id": 7},
        }))
        .expect("parse request");

        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare");
        assert_eq!(prepared.text_request.session_id, None);
    }

    #[test]
    fn prepare_completion_request_leaves_data_parallel_rank_none_when_absent() {
        let request: CompletionRequest = serde_json::from_value(json!({
            "model": "Qwen/Qwen1.5-0.5B-Chat",
            "prompt": "hello",
            "stream": false,
        }))
        .expect("parse request");

        let prepared = prepare_completion_request(
            request,
            &served(&["Qwen/Qwen1.5-0.5B-Chat"]),
            ResolvedRequestContext::default(),
            &test_tokenizer(),
        )
        .expect("prepare");
        assert_eq!(prepared.text_request.data_parallel_rank, None);
    }
}
