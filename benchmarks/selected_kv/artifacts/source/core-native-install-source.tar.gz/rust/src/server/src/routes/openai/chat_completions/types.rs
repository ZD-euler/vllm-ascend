// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright contributors to the vLLM project

use std::collections::HashMap;
use std::fmt;
use std::sync::Arc;

use serde::{Deserialize, Serialize};
use serde_json::Value;
use serde_with::SerializeDisplay;
use validator::Validate;
use vllm_engine_core_client::protocol::sampling::RepetitionDetectionParams;
use vllm_text::TruncationSide;

use crate::routes::openai::utils::structured_outputs::ResponseFormat;
use crate::routes::openai::utils::types::{
    ChatLogProbs, ChatMessage, Normalizable, PromptLogprobs, ReasoningEffort, StreamOptions,
    StreamResponseEnvelope, StringOrArray, Tool, ToolCall, ToolCallDelta, ToolChoice, Usage,
    default_true, deserialize_request_top_k, validate_messages, validate_stop,
    validate_top_p_value,
};

/// vLLM-compatible request type for the Chat Completions API.
///
/// Mirrors the Python vLLM `ChatCompletionRequest` class. The local copy keeps
/// the request type route-owned so we can add vLLM-only fields directly instead
/// of layering wrapper deserializers on top.
#[serde_with::skip_serializing_none]
#[derive(Debug, Clone, Deserialize, Serialize, Validate)]
#[validate(schema(function = "validate_chat_cross_parameters"))]
pub struct ChatCompletionRequest {
    // -------- Standard OpenAI API Parameters --------
    /// A list of messages comprising the conversation so far
    #[validate(custom(function = "validate_messages"))]
    pub messages: Vec<ChatMessage>,

    /// ID of the model to use
    pub model: Option<String>,

    /// Number between -2.0 and 2.0. Positive values penalize new tokens based
    /// on their existing frequency in the text so far
    #[validate(range(min = -2.0, max = 2.0))]
    pub frequency_penalty: Option<f32>,

    /// Modify the likelihood of specified tokens appearing in the completion
    pub logit_bias: Option<HashMap<String, f32>>,

    /// Whether to return log probabilities of the output tokens
    #[serde(default)]
    pub logprobs: bool,

    /// An integer specifying the number of most likely tokens to return
    /// -1 means return all
    #[validate(range(min = -1))]
    pub top_logprobs: Option<i32>,

    /// Deprecated: Replaced by max_completion_tokens
    #[deprecated(note = "Use max_completion_tokens instead")]
    #[validate(range(min = 1))]
    pub max_tokens: Option<u32>,

    /// An upper bound for the number of tokens that can be generated for a
    /// completion
    #[validate(range(min = 1))]
    pub max_completion_tokens: Option<u32>,

    /// How many chat completion choices to generate for each input message
    #[validate(range(min = 1, max = 10))]
    pub n: Option<u32>,

    /// Number between -2.0 and 2.0. Positive values penalize new tokens based
    /// on whether they appear in the text so far
    #[validate(range(min = -2.0, max = 2.0))]
    pub presence_penalty: Option<f32>,

    /// An object specifying the format that the model must output
    pub response_format: Option<ResponseFormat>,

    /// If specified, our system will make a best effort to sample
    /// deterministically
    pub seed: Option<i64>,

    /// Up to 4 sequences where the API will stop generating further tokens
    #[validate(custom(function = "validate_stop"))]
    pub stop: Option<StringOrArray>,

    /// If set, partial message deltas will be sent
    #[serde(default)]
    pub stream: bool,

    /// Options for streaming response
    pub stream_options: Option<StreamOptions>,

    /// What sampling temperature to use, between 0 and 2
    #[validate(range(min = 0.0, max = 2.0))]
    pub temperature: Option<f32>,

    /// An alternative to sampling with temperature
    #[validate(custom(function = "validate_top_p_value"))]
    pub top_p: Option<f32>,

    /// A list of tools the model may call
    pub tools: Option<Vec<Tool>>,

    /// Controls which (if any) tool is called by the model
    pub tool_choice: Option<ToolChoice>,

    /// Effort level for reasoning models (none, minimal, low, medium, high,
    /// xhigh, max)
    pub reasoning_effort: Option<ReasoningEffort>,

    /// Whether to enable parallel function calling during tool use
    pub parallel_tool_calls: Option<bool>,

    /// A unique identifier representing your end-user
    pub user: Option<String>,

    // -------- vLLM Sampling Parameters --------
    /// Whether to apply the engine's configured watermark to this request.
    #[serde(default = "default_true")]
    pub watermarking: bool,

    /// Use beam search instead of sampling
    #[serde(default)]
    pub use_beam_search: bool,

    /// Top-k sampling parameter
    #[serde(default, deserialize_with = "deserialize_request_top_k")]
    pub top_k: Option<u32>,

    /// Min-p nucleus sampling parameter
    #[validate(range(min = 0.0, max = 1.0))]
    pub min_p: Option<f32>,

    /// Repetition penalty for reducing repetitive text
    #[validate(range(min = 0.0, max = 2.0))]
    pub repetition_penalty: Option<f32>,

    /// Length penalty for beam search
    pub length_penalty: Option<f32>,

    /// Specific token IDs to use as stop conditions
    pub stop_token_ids: Option<Vec<u32>>,

    /// Include stop string in output
    #[serde(default)]
    pub include_stop_str_in_output: bool,

    /// Ignore end-of-sequence tokens during generation
    #[serde(default)]
    pub ignore_eos: bool,

    /// Minimum number of tokens to generate
    pub min_tokens: Option<u32>,

    /// Skip special tokens during detokenization
    #[serde(default = "default_true")]
    pub skip_special_tokens: bool,

    /// Add spaces between special tokens during detokenization
    #[serde(default = "default_true")]
    pub spaces_between_special_tokens: bool,

    /// Truncate prompt tokens to this length
    pub truncate_prompt_tokens: Option<i64>,

    /// Which side to truncate from when truncate_prompt_tokens is active
    pub truncation_side: Option<TruncationSide>,

    /// Number of prompt logprobs to return
    pub prompt_logprobs: Option<i32>,

    /// Restrict output to these token IDs only
    pub allowed_token_ids: Option<Vec<u32>>,

    /// List of bad words to avoid during generation
    pub bad_words: Option<Vec<String>>,

    // -------- Extra vLLM Parameters --------
    /// Token budget for reasoning/thinking. Accepts a non-negative integer, or
    /// `-1` for unlimited (mirroring the Python frontend, which normalizes `-1`
    /// to "no budget").
    pub thinking_token_budget: Option<i64>,

    /// Whether to include reasoning content in the response
    #[serde(default = "default_true")]
    pub include_reasoning: bool,

    /// If true, the new message will be prepended with the last message if they
    /// belong to the same role.
    #[serde(default)]
    pub echo: bool,

    /// Whether to add the generation prompt to the chat template.
    ///
    /// When omitted, the request follows the API default behavior, which is
    /// equivalent to `true` unless `continue_final_message=true` selects
    /// final assistant continuation instead.
    pub add_generation_prompt: Option<bool>,

    /// Continue generating from final assistant message
    #[serde(default)]
    pub continue_final_message: bool,

    /// Whether to add special tokens (e.g. BOS) to the prompt
    #[serde(default)]
    pub add_special_tokens: bool,

    /// Documents for RAG (retrieval-augmented generation)
    pub documents: Option<Vec<Value>>,

    /// Jinja chat template override
    pub chat_template: Option<String>,

    /// Additional keyword args passed to the chat template renderer
    pub chat_template_kwargs: Option<HashMap<String, Value>>,

    /// Additional kwargs for media IO connectors, keyed by modality
    pub media_io_kwargs: Option<HashMap<String, Value>>,

    /// Additional kwargs for the HF processor
    pub mm_processor_kwargs: Option<HashMap<String, Value>>,

    /// Additional kwargs for structured outputs
    pub structured_outputs: Option<Value>,

    /// Request scheduling priority (lower means earlier; default 0)
    pub priority: Option<i32>,

    /// External request ID used for response correlation.
    pub request_id: Option<String>,

    /// Stable session identity shared by related requests.
    pub session_id: Option<String>,

    /// Tokens represented as strings of the form 'token_id:{token_id}' in
    /// logprobs
    pub return_tokens_as_token_ids: Option<bool>,

    /// Include token IDs alongside generated text
    pub return_token_ids: Option<bool>,

    /// Salt for prefix cache isolation in multi-user environments
    #[validate(length(min = 1))]
    pub cache_salt: Option<String>,

    /// KV transfer parameters for disaggregated serving
    pub kv_transfer_params: Option<HashMap<String, Value>>,

    /// Encoder cache transfer parameters for disaggregated serving
    pub ec_transfer_params: Option<HashMap<String, Value>>,

    /// Additional request parameters with string or numeric values for custom
    /// extensions
    pub vllm_xargs: Option<HashMap<String, Value>>,

    /// Parameters for detecting repetitive N-gram patterns in output tokens
    pub repetition_detection: Option<RepetitionDetectionParams>,
}

impl Default for ChatCompletionRequest {
    #[expect(deprecated)]
    fn default() -> Self {
        Self {
            messages: Vec::new(),
            model: None,
            frequency_penalty: None,
            logit_bias: None,
            logprobs: false,
            top_logprobs: None,
            max_tokens: None,
            max_completion_tokens: None,
            n: None,
            presence_penalty: None,
            response_format: None,
            seed: None,
            stop: None,
            stream: false,
            stream_options: None,
            temperature: None,
            top_p: None,
            tools: None,
            tool_choice: None,
            reasoning_effort: None,
            thinking_token_budget: None,
            include_reasoning: true,
            parallel_tool_calls: None,
            user: None,
            watermarking: true,
            use_beam_search: false,
            top_k: None,
            min_p: None,
            repetition_penalty: None,
            length_penalty: None,
            stop_token_ids: None,
            include_stop_str_in_output: false,
            ignore_eos: false,
            min_tokens: None,
            skip_special_tokens: true,
            spaces_between_special_tokens: true,
            truncate_prompt_tokens: None,
            truncation_side: None,
            prompt_logprobs: None,
            allowed_token_ids: None,
            bad_words: None,
            echo: false,
            add_generation_prompt: None,
            continue_final_message: false,
            add_special_tokens: false,
            documents: None,
            chat_template: None,
            chat_template_kwargs: None,
            media_io_kwargs: None,
            mm_processor_kwargs: None,
            structured_outputs: None,
            priority: None,
            request_id: None,
            session_id: None,
            return_tokens_as_token_ids: None,
            return_token_ids: None,
            cache_salt: None,
            kv_transfer_params: None,
            ec_transfer_params: None,
            vllm_xargs: None,
            repetition_detection: None,
        }
    }
}

impl Normalizable for ChatCompletionRequest {
    /// Normalize the request by applying migrations and defaults.
    fn normalize(&mut self) {
        // Migrate deprecated max_tokens → max_completion_tokens
        #[expect(deprecated)]
        if self.max_completion_tokens.is_none() && self.max_tokens.is_some() {
            self.max_completion_tokens = self.max_tokens;
            self.max_tokens = None;
        }
    }
}

/// Mirrors the Python vLLM `ChatCompletionResponse` class.
///
/// Do not skip serializing `None` fields here: non-streaming response types
/// should serialize `None` as explicit `null`.
#[derive(Debug, Clone, Serialize)]
pub(super) struct ChatCompletionResponse {
    pub id: String,
    pub object: String,
    pub created: u64,
    pub model: String,
    pub choices: Vec<ChatCompletionChoice>,
    pub usage: Option<Usage>,
    pub system_fingerprint: Option<String>,
    pub prompt_logprobs: Option<PromptLogprobs>,
    pub prompt_token_ids: Option<Vec<u32>>,
    pub kv_transfer_params: Option<Value>,
    pub ec_transfer_params: Option<Value>,
}

/// Mirrors the Python vLLM `ChatCompletionResponseChoice` class.
#[derive(Debug, Clone, Serialize)]
pub(super) struct ChatCompletionChoice {
    pub index: u32,
    pub message: ChatCompletionMessage,
    pub logprobs: Option<ChatLogProbs>,
    pub finish_reason: Option<String>,
    pub stop_reason: Option<Value>,
    pub token_ids: Option<Vec<u32>>,
}

/// A literal type for the "assistant" role, since the API only allows that
/// specific value in responses.
#[derive(Debug, Clone, Copy, PartialEq, Eq, SerializeDisplay)]
pub(super) struct AssistantRole;

impl fmt::Display for AssistantRole {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("assistant")
    }
}

/// Mirrors the Python vLLM response `ChatMessage` class.
#[derive(Debug, Clone, Serialize)]
pub(super) struct ChatCompletionMessage {
    pub role: AssistantRole,
    pub content: Option<String>,
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub tool_calls: Vec<ToolCall>,
    pub reasoning: Option<String>,
}

/// Mirrors the Python vLLM `ChatCompletionStreamResponse` class.
#[serde_with::skip_serializing_none]
#[derive(Debug, Clone, Serialize)]
pub(super) struct ChatCompletionStreamResponse {
    #[serde(flatten)]
    pub envelope: Arc<StreamResponseEnvelope>,
    pub choices: Vec<ChatCompletionStreamChoice>,
    pub usage: Option<Usage>,
    pub prompt_token_ids: Option<Vec<u32>>,
}

impl ChatCompletionStreamResponse {
    /// Create a stream response with the standard envelope fields pre-filled.
    pub fn new(envelope: &Arc<StreamResponseEnvelope>) -> Self {
        Self {
            envelope: Arc::clone(envelope),
            choices: Vec::new(),
            usage: None,
            prompt_token_ids: None,
        }
    }
}

/// Mirrors the Python vLLM `ChatCompletionResponseStreamChoice` class.
#[serde_with::skip_serializing_none]
#[derive(Debug, Clone, Default, Serialize)]
pub(super) struct ChatCompletionStreamChoice {
    pub index: u32,
    pub delta: ChatMessageDelta,
    pub logprobs: Option<ChatLogProbs>,
    pub finish_reason: Option<String>,
    pub stop_reason: Option<Value>,
    pub token_ids: Option<Vec<u32>>,
}

/// Mirrors the Python vLLM `DeltaMessage` class.
#[serde_with::skip_serializing_none]
#[derive(Debug, Clone, Default, Serialize)]
pub(super) struct ChatMessageDelta {
    pub role: Option<AssistantRole>,
    pub content: Option<String>,
    pub tool_calls: Option<Vec<ToolCallDelta>>,
    pub reasoning: Option<String>,
}

/// Schema-level validation for cross-field dependencies
fn validate_chat_cross_parameters(
    req: &ChatCompletionRequest,
) -> Result<(), validator::ValidationError> {
    // 1. Validate logprobs dependency
    if req.top_logprobs.is_some() && !req.logprobs {
        let mut e = validator::ValidationError::new("top_logprobs_requires_logprobs");
        e.message = Some("top_logprobs is only allowed when logprobs is enabled".into());
        return Err(e);
    }

    // 2. Validate stream_options dependency
    if req.stream_options.is_some() && !req.stream {
        let mut e = validator::ValidationError::new("stream_options_requires_stream");
        e.message = Some("stream_options can only be used when stream is true".into());
        return Err(e);
    }

    // 3. Validate token limits - min <= max
    if let (Some(min_tokens), Some(max_completion_tokens)) =
        (req.min_tokens, req.max_completion_tokens)
        && min_tokens > max_completion_tokens
    {
        let mut e = validator::ValidationError::new("min_tokens_exceeds_max_completion_tokens");
        e.message = Some("min_tokens cannot be greater than max_completion_tokens".into());
        return Err(e);
    }

    #[expect(deprecated, reason = "Local type still mirrors legacy upstream field")]
    if let (Some(min_tokens), Some(max_tokens)) = (req.min_tokens, req.max_tokens)
        && min_tokens > max_tokens
    {
        let mut e = validator::ValidationError::new("min_tokens_exceeds_max_tokens");
        e.message = Some("min_tokens cannot be greater than max_tokens".into());
        return Err(e);
    }

    // 4. Validate response format JSON schema name
    if let Some(ResponseFormat::JsonSchema { json_schema }) = &req.response_format
        && json_schema.name.is_empty()
    {
        let mut e = validator::ValidationError::new("json_schema_name_empty");
        e.message = Some("JSON schema name cannot be empty".into());
        return Err(e);
    }

    Ok(())
}
